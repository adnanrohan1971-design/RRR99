
const express = require('express');
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cors = require('cors');
const path = require('path');

const app = express();
const db = new Database('data.db');
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'CHANGE_ME_TO_A_RANDOM_SECRET';

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ---- DB INIT ----
db.exec(`
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'admin'
);
CREATE TABLE IF NOT EXISTS providers(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL
);
CREATE TABLE IF NOT EXISTS games(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  provider_id INTEGER NOT NULL,
  tag TEXT,
  image_url TEXT,
  rating REAL DEFAULT 4.5,
  plays INTEGER DEFAULT 0,
  FOREIGN KEY(provider_id) REFERENCES providers(id)
);
`);

// seed admin
const adminEmail = 'admin@example.com';
const adminPass = 'admin123'; // change after first login
let adminRow = db.prepare('SELECT * FROM users WHERE email=?').get(adminEmail);
if(!adminRow){
  const hash = bcrypt.hashSync(adminPass, 10);
  db.prepare('INSERT INTO users(email,password_hash,role) VALUES (?,?,?)').run(adminEmail, hash, 'admin');
  console.log('Seeded admin user:', adminEmail, 'password:', adminPass);
}

// seed providers if empty
const provCount = db.prepare('SELECT COUNT(*) AS c FROM providers').get().c;
if(provCount === 0){
  const seed = [
    {name:'JILI', slug:'jili'},
    {name:'PG', slug:'pg'},
    {name:'BNG', slug:'bng'},
    {name:'FC', slug:'fc'}
  ];
  const stmt = db.prepare('INSERT INTO providers(name,slug) VALUES (?,?)');
  for(const p of seed) stmt.run(p.name, p.slug);
  console.log('Seeded providers');
}

// seed games if empty
const gameCount = db.prepare('SELECT COUNT(*) AS c FROM games').get().c;
if(gameCount === 0){
  const getProvId = (slug)=> db.prepare('SELECT id FROM providers WHERE slug=?').get(slug).id;
  const seedGames = [
    {title:'Super Ace', provider:'jili', tag:'1500x', image_url:'https://picsum.photos/seed/ace/500/500'},
    {title:'Fortune Gems 3', provider:'jili', tag:'NEW', image_url:'https://picsum.photos/seed/gems/500/500'},
    {title:'Mahjong Ways', provider:'pg', tag:'HOT', image_url:'https://picsum.photos/seed/mahjong/500/500'},
    {title:'Candy Burst', provider:'pg', tag:'SWEET', image_url:'https://picsum.photos/seed/candy/500/500'},
    {title:'Sun of Egypt', provider:'bng', tag:'1000x', image_url:'https://picsum.photos/seed/egypt/500/500'},
    {title:'15 Dragon Pearls', provider:'bng', tag:'HOLD&WIN', image_url:'https://picsum.photos/seed/dragon/500/500'},
    {title:'Fortune Crown', provider:'fc', tag:'2000x', image_url:'https://picsum.photos/seed/crown/500/500'}
  ];
  const stmt = db.prepare('INSERT INTO games(title,provider_id,tag,image_url,rating,plays) VALUES (?,?,?,?,?,?)');
  for(const g of seedGames){
    stmt.run(g.title, getProvId(g.provider), g.tag, g.image_url, 4.6, Math.floor(Math.random()*20000)+1000);
  }
  console.log('Seeded games');
}

// ---- Helpers ----
function auth(req, res, next){
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if(!token) return res.status(401).json({error:'No token'});
  try{
    const payload = jwt.verify(token, JWT_SECRET);
    req.user = payload;
    next();
  }catch(e){
    return res.status(401).json({error:'Invalid token'});
  }
}

function adminOnly(req,res,next){
  if(req.user && req.user.role === 'admin') return next();
  return res.status(403).json({error:'Forbidden'});
}

// ---- Auth ----
app.post('/api/auth/login', (req,res)=>{
  const {email, password} = req.body;
  const user = db.prepare('SELECT * FROM users WHERE email=?').get(email || '');
  if(!user) return res.status(401).json({error:'Invalid credentials'});
  const ok = bcrypt.compareSync(password || '', user.password_hash);
  if(!ok) return res.status(401).json({error:'Invalid credentials'});
  const token = jwt.sign({id:user.id, email:user.email, role:user.role}, JWT_SECRET, {expiresIn:'7d'});
  res.json({token, email:user.email});
});

// ---- Public APIs ----
app.get('/api/providers', (req,res)=>{
  const rows = db.prepare('SELECT * FROM providers ORDER BY name').all();
  res.json(rows);
});

app.get('/api/games', (req,res)=>{
  const {provider} = req.query; // provider slug (optional)
  if(provider){
    const rows = db.prepare(`
      SELECT g.*, p.slug AS provider_slug, p.name AS provider_name
      FROM games g JOIN providers p ON g.provider_id=p.id
      WHERE p.slug=? ORDER BY g.id DESC
    `).all(provider);
    return res.json(rows);
  }else{
    const rows = db.prepare(`
      SELECT g.*, p.slug AS provider_slug, p.name AS provider_name
      FROM games g JOIN providers p ON g.provider_id=p.id
      ORDER BY g.id DESC
    `).all();
    return res.json(rows);
  }
});

// ---- Admin APIs ----
app.get('/api/users', auth, adminOnly, (req,res)=>{
  const rows = db.prepare('SELECT id,email,role FROM users ORDER BY id DESC').all();
  res.json(rows);
});

app.post('/api/providers', auth, adminOnly, (req,res)=>{
  const {name, slug} = req.body;
  if(!name || !slug) return res.status(400).json({error:'name & slug required'});
  try{
    const info = db.prepare('INSERT INTO providers(name,slug) VALUES (?,?)').run(name, slug);
    res.json({id:info.lastInsertRowid, name, slug});
  }catch(e){
    res.status(400).json({error:'duplicate or invalid'});
  }
});

app.put('/api/providers/:id', auth, adminOnly, (req,res)=>{
  const {name, slug} = req.body;
  const id = req.params.id;
  const info = db.prepare('UPDATE providers SET name=?, slug=? WHERE id=?').run(name, slug, id);
  res.json({updated:info.changes});
});

app.delete('/api/providers/:id', auth, adminOnly, (req,res)=>{
  const id = req.params.id;
  db.prepare('DELETE FROM games WHERE provider_id=?').run(id);
  const info = db.prepare('DELETE FROM providers WHERE id=?').run(id);
  res.json({deleted:info.changes});
});

app.post('/api/games', auth, adminOnly, (req,res)=>{
  const {title, provider_slug, tag, image_url, rating, plays} = req.body;
  const prov = db.prepare('SELECT id FROM providers WHERE slug=?').get(provider_slug);
  if(!prov) return res.status(400).json({error:'provider not found'});
  const info = db.prepare('INSERT INTO games(title,provider_id,tag,image_url,rating,plays) VALUES (?,?,?,?,?,?)')
              .run(title, prov.id, tag || null, image_url || null, rating || 4.5, plays || 0);
  res.json({id:info.lastInsertRowid});
});

app.put('/api/games/:id', auth, adminOnly, (req,res)=>{
  const id = req.params.id;
  // update subset
  const game = db.prepare('SELECT * FROM games WHERE id=?').get(id);
  if(!game) return res.status(404).json({error:'not found'});
  const fields = {
    title: req.body.title ?? game.title,
    tag: req.body.tag ?? game.tag,
    image_url: req.body.image_url ?? game.image_url,
    rating: req.body.rating ?? game.rating,
    plays: req.body.plays ?? game.plays,
  };
  if(req.body.provider_slug){
    const prov = db.prepare('SELECT id FROM providers WHERE slug=?').get(req.body.provider_slug);
    if(!prov) return res.status(400).json({error:'provider not found'});
    fields.provider_id = prov.id;
  } else {
    fields.provider_id = game.provider_id;
  }
  const info = db.prepare('UPDATE games SET title=?, provider_id=?, tag=?, image_url=?, rating=?, plays=? WHERE id=?')
                .run(fields.title, fields.provider_id, fields.tag, fields.image_url, fields.rating, fields.plays, id);
  res.json({updated: info.changes});
});

app.delete('/api/games/:id', auth, adminOnly, (req,res)=>{
  const id = req.params.id;
  const info = db.prepare('DELETE FROM games WHERE id=?').run(id);
  res.json({deleted: info.changes});
});

// ---- Fallback to SPA files ----
app.get('/admin', (req,res)=>{
  res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});
app.get('/', (req,res)=>{
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, ()=> console.log(`Server running on http://localhost:${PORT}`));
